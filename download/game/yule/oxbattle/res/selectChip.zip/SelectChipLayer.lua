--
-- Author: fei
-- Date: 2019-03-17 16:40:04
--
--更换筹码
local ExternalFun = appdf.req(appdf.EXTERNAL_SRC .. "ExternalFun")

local SelectChipLayer = class("SelectChipLayer", cc.Layer)

SelectChipLayer.BT_CLOSE = 1
SelectChipLayer.BT_BG 	= 2

function SelectChipLayer:ctor(callBack)
	self.callBack = callBack

	--加载csb资源
	local csbNode = ExternalFun.loadCSB("selectChip/SelectChipNode.csb", self)
	csbNode:setPosition(yl.WIDTH * 0.5, yl.HEIGHT * 0.5)
	self._csbNode = csbNode
	
	local applylist_bg = csbNode:getChildByName("applylist_bg")
	applylist_bg:setSwallowTouches(true)

	self.sp_select = applylist_bg:getChildByName("sp_select")
	print("self.sp_select",self.sp_select)
	self.nSelect = 1

	--关闭按钮
	local function btnEvent( sender, eventType )
		if eventType == ccui.TouchEventType.ended then
			self:onButtonClickedEvent(sender:getTag(), sender);
		end
	end

	local btn_close = csbNode:getChildByName("btn_close")
	btn_close:setTag(SelectChipLayer.BT_CLOSE)
	btn_close:addTouchEventListener(btnEvent)
	btn_close:getRendererClicked():setScale(1.1)

	for i=1,10 do
		local btn = applylist_bg:getChildByName("Button_"..i)
		btn:setTag(10+i)
		btn:setLocalZOrder(1)
		btn:addTouchEventListener(btnEvent)
	end

	local layoutbg = csbNode:getChildByName("layout_bg")
	layoutbg:setTag(SelectChipLayer.BT_BG)
	layoutbg:addTouchEventListener(btnEvent)

	local function selectBtn( sender, eventType )
		if eventType == ccui.TouchEventType.ended then
			self:onSelectClickedEvent(sender:getTag(), sender)
		end
	end
	--更换筹码按钮

	local btn_select_chip = csbNode:getChildByName("btn_select_chip")
	btn_select_chip:addTouchEventListener(selectBtn)
	btn_select_chip:getRendererClicked():setScale(1.1)
	self.m_btnApply = btn_select_chip

	
	self:showAni()
end

function SelectChipLayer:onButtonClickedEvent( tag, sender )
	if SelectChipLayer.BT_CLOSE == tag then
		ExternalFun.playClickEffect()
		self:setVisible(false)
	elseif SelectChipLayer.BT_BG == tag then
		self:dismissAni()
	else
		local nIndex = tag - 10
		if self.nSelect ~= nIndex then
			self.nSelect = nIndex
			local posX,posY = sender:getPosition()
			self.sp_select:setPosition(posX,posY)
		end
	end
end

function SelectChipLayer:onSelectClickedEvent( tag,sender )
	ExternalFun.playClickEffect()
	-- 更换筹码
	local tChip = {1,5,10,50,100,500,1000,5000,10000,50000}
	self.callBack(tChip[self.nSelect] or 1)
	self:dismissAni()
end

--弹出动画
function SelectChipLayer:showAni(callBack)
	self:setVisible(true)
    self._csbNode:setScale(0)
    ExternalFun.popupTouchFilter()

    self._csbNode:runAction(cc.Sequence:create(cc.EaseBackOut:create(cc.ScaleTo:create(0.3, 1.0)), cc.CallFunc:create(function()
        ExternalFun.dismissTouchFilter()
		if callBack then
			callBack()
		end
    end)))
end

--收起动画
function SelectChipLayer:dismissAni(callBack)
    ExternalFun.popupTouchFilter()

    self._csbNode:runAction(cc.Sequence:create(cc.EaseBackIn:create(cc.ScaleTo:create(0.2, 0.0)), cc.CallFunc:create(function()
        ExternalFun.dismissTouchFilter()
		if callBack then
			callBack()
		end
		self:setVisible(false)
    end)))
end

return SelectChipLayer